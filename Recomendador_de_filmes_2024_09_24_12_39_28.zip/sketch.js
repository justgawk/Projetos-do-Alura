let campoIdade;
let campoFantasia;   
let campoAventura;

function setup() {
  createCanvas(800, 400);
  createElement("h2", "Recomendador de filmes");
  createSpan("Sua idade:");
  campoIdade = createInput("5");
  campoFantasia = createCheckbox("Gosta de fantasia?");
  campoAventura = createCheckbox("Gosta de aventura?");
}

function draw() {
  background("violet");
  let idade = campoIdade.value();
  let gostaDeFantasia = campoFantasia.checked();
  let gostaDeAventura = campoAventura.checked();
  let recomendacao = geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura);
  
  fill(color(76, 0, 115));
  textAlign(CENTER, CENTER);
  textSize(38);
  text(recomendacao, width / 2, height / 2);
}

function geraRecomendacao(idade, gostaDeFantasia, gostaDeAventura) {
  if (idade >= 10) {
    if (idade >= 14) {
      return "Os Guardiões da Galáxia 3";
    } else {
      if (idade >= 12) {
        if (gostaDeFantasia || gostaDeAventura){
            return "Homem Aranha através do Aranhaverso";
        } else {
            return "Harry Potter e as Relíquias da Morte: Parte 2";
        }
      } else {
        if (gostaDeFantasia) {
          return "A Pequena Sereia";
        } else {
          return "Uncharted";
        }
      }
    }
  } else {
    if (gostaDeFantasia) {
      return "Alice no País das Maravilhas";
    } else {
      return "Coraline";
    }
  }
}
